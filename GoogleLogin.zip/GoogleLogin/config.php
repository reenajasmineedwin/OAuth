<?php
    session_start();
    require_once "GoogleAPI/vendor/autoload.php";
    $gClient = new Google_Client();
    $gClient->setClientId("355089651885-0a2tc11ldoeu2setkv2m73v69vkvhh9c.apps.googleusercontent.com");
    $gClient->setClientSecret("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");
    $gClient->setApplicationName("CPI Login Demo");
    $gClient->setRedirectUri("http://localhost/GoogleLogin/g-callback.php");
    $gClient->addScope(scope_or_scopes: "https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");

?>