<?php

//config.php

//Include Google Client Library for PHP autoload file
require_once 'GoogleAPI/vendor/autoload.php';

//Make object of Google API Client for call Google API
$google_client = new Google_Client();

//Set the OAuth 2.0 Client ID
$google_client->setClientId('355089651885-0a2tc11ldoeu2setkv2m73v69vkvhh9c.apps.googleusercontent.com');

//Set the OAuth 2.0 Client Secret key
$google_client->setClientSecret('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');

//Set the OAuth 2.0 Redirect URI
$google_client->setRedirectUri('http://localhost/gl/index.php');

//
$google_client->addScope('email');

$google_client->addScope('profile');

//start session on web page
session_start();

?>
